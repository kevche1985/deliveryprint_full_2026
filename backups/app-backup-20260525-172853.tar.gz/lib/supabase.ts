import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl) {
  throw new Error("Missing Supabase URL")
}

if (!supabaseAnonKey) {
  throw new Error("Missing Supabase anon key")
}

// Client-side Supabase client
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  db: {
    schema: "public",
  },
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
  },
  global: {
    headers: {
      "X-Client-Info": "print-on-demand-mvp",
    },
  },
})

// Server-side client with service role key for admin operations
export const supabaseAdmin =
  typeof window === "undefined" && !!supabaseServiceKey
    ? createClient(supabaseUrl, supabaseServiceKey!, {
        db: {
          schema: "public",
        },
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
        global: {
          headers: {
            "X-Client-Info": "print-on-demand-admin",
          },
        },
      })
    : null

// Test connection function
export async function testConnection() {
  try {
    console.log("Testing Supabase connection to:", supabaseUrl)

    // Try to get session (this tests auth connection)
    const {
      data: { session },
      error,
    } = await supabase.auth.getSession()

    if (error && error.message !== "Auth session missing!") {
      console.error("Connection test failed:", error)
      return false
    }

    console.log("Supabase connection successful")
    return true
  } catch (error) {
    console.error("Connection test error:", error)
    return false
  }
}

// Test table access
export async function testTableAccess() {
  try {
    console.log("Testing table access...")

    const { data, error } = await supabase.from("products").select("count", { count: "exact", head: true })

    if (error) {
      console.error("Table access test failed:", error)
      return false
    }

    console.log("Table access successful, count:", data)
    return true
  } catch (error) {
    console.error("Table access error:", error)
    return false
  }
}

export type Database = {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string
          first_name: string
          last_name: string
          phone: string | null
          address: any | null
          role: "admin" | "operator" | "customer" | "supplier"
          status: "active" | "suspended" | "pending"
          avatar_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: Omit<Database["public"]["Tables"]["user_profiles"]["Row"], "created_at" | "updated_at">
        Update: Partial<Database["public"]["Tables"]["user_profiles"]["Insert"]>
      }
      products: {
        Row: {
          id: string
          name: string
          short_description: string | null
          description: string | null
          technique: string | null
          has_archive_guide: boolean | null
          accepts_uploads: boolean | null
          is_customizable: boolean | null
          rating: number | null
          review_count: number | null
          wholesale_tiers: any | null
          specifications: any | null
          shipping_info: string | null
          price: number
          category: string | null
          image: string | null
          is_active: boolean
          is_featured: boolean
          tenant_id: string | null
          created_at: string
          updated_at: string
        }
      }
      product_media: {
        Row: {
          id: string
          tenant_id: string | null
          product_id: string
          storage_path: string
          type: string
          alt_text: string | null
          sort_order: number | null
          created_at: string
        }
      }
      product_variant_groups: {
        Row: {
          id: string
          tenant_id: string | null
          product_id: string
          name: string
          display: string
          sort_order: number | null
          created_at: string
        }
      }
      product_variant_options: {
        Row: {
          id: string
          tenant_id: string | null
          group_id: string
          label: string
          price_modifier: number
          is_available: boolean | null
          sort_order: number | null
          created_at: string
        }
      }
      orders: {
        Row: {
          id: string
          order_number: string
          user_id: string | null
          email: string
          status: string
          subtotal: number
          tax: number
          shipping: number
          discount: number
          total: number
          shipping_address: any | null
          billing_address: any | null
          payment_method: string | null
          shipping_method: string
          notes: string | null
          currency: string
          created_at: string
          updated_at: string
        }
      }
      categories: {
        Row: {
          id: string
          name: string
          slug: string
          description: string | null
          parent_id: string | null
          image_url: string | null
          is_active: boolean
          created_at: string
          updated_at: string
        }
      }
      quotes: {
        Row: {
          id: string
          quote_number: string
          customer_name: string
          customer_email: string
          customer_phone: string | null
          status: string
          notes: string | null
          customer_id: string | null
          created_by: string | null
          valid_until: string | null
          currency: string
          created_at: string
          updated_at: string
        }
      }
      support_tickets: {
        Row: {
          id: string
          ticket_number: string
          customer_name: string
          customer_email: string
          subject: string
          message: string
          status: string
          priority: string
          assigned_to: string | null
          customer_id: string | null
          created_at: string
          updated_at: string
        }
      }
    }
  }
}
