"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { 
  RefreshCw, 
  Database, 
  Image, 
  CheckCircle, 
  AlertTriangle, 
  Info,
  Play,
  Eye
} from 'lucide-react'

interface MigrationStats {
  total: number
  withDesignImages: number
  withProductImages: number
  withCustomizedImages: number
  needsMigration: number
}

interface MigrationResult {
  success: boolean
  message: string
  dryRun?: boolean
  stats?: MigrationStats
  preview?: any[]
  totalChanges?: number
  results?: {
    updatedCount: number
    errorCount: number
    errors: any[]
    beforeStats: MigrationStats
    afterStats: MigrationStats
    improvement: {
      designImages: number
      productImages: number
      customizedImages: number
    }
  }
}

export default function MigrateImagesPage() {
  const [stats, setStats] = useState<MigrationStats | null>(null)
  const [coverage, setCoverage] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [migrationResult, setMigrationResult] = useState<MigrationResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  const fetchStats = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/admin/migrate-order-images')
      const data = await response.json()
      
      if (data.error) {
        setError(data.error)
      } else {
        setStats(data.stats)
        setCoverage(data.coverage)
      }
    } catch (err) {
      setError('Failed to fetch migration status')
    } finally {
      setLoading(false)
    }
  }

  const runMigration = async (dryRun: boolean = false) => {
    try {
      setLoading(true)
      setError(null)
      setMigrationResult(null)
      
      const response = await fetch('/api/admin/migrate-order-images', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ dryRun })
      })
      
      const result = await response.json()
      
      if (result.error) {
        setError(result.error)
      } else {
        setMigrationResult(result)
        if (!dryRun) {
          // Refresh stats after successful migration
          await fetchStats()
        }
      }
    } catch (err) {
      setError('Failed to run migration')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchStats()
  }, [])

  const getProgressColor = (percentage: number) => {
    if (percentage >= 80) return 'bg-green-500'
    if (percentage >= 50) return 'bg-yellow-500'
    return 'bg-red-500'
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Order Items Image Migration</h1>
          <p className="text-gray-600 mt-2">
            Migrate image data for existing order items that were created before the new image system.
          </p>
        </div>
        <Button 
          onClick={fetchStats} 
          disabled={loading}
          variant="outline"
          size="sm"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Current Status */}
      {stats && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Current Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="text-center">
                <div className="text-2xl font-bold">{stats.total}</div>
                <div className="text-sm text-gray-600">Total Order Items</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{stats.withDesignImages}</div>
                <div className="text-sm text-gray-600">With Design Images</div>
                <div className="text-xs text-gray-500">{coverage?.designImages}</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{stats.withProductImages}</div>
                <div className="text-sm text-gray-600">With Product Images</div>
                <div className="text-xs text-gray-500">{coverage?.productImages}</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{stats.withCustomizedImages}</div>
                <div className="text-sm text-gray-600">With Customized Images</div>
                <div className="text-xs text-gray-500">{coverage?.customizedImages}</div>
              </div>
            </div>

            <Separator className="my-4" />

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Design Images Coverage</span>
                <span className="text-sm text-gray-600">{coverage?.designImages}</span>
              </div>
              <Progress 
                value={(stats.withDesignImages / stats.total) * 100} 
                className="h-2"
              />
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Product Images Coverage</span>
                <span className="text-sm text-gray-600">{coverage?.productImages}</span>
              </div>
              <Progress 
                value={(stats.withProductImages / stats.total) * 100} 
                className="h-2"
              />
            </div>

            {stats.needsMigration > 0 && (
              <Alert className="mt-4">
                <Info className="h-4 w-4" />
                <AlertDescription>
                  <strong>{stats.needsMigration} order items</strong> can be migrated to add missing image data.
                </AlertDescription>
              </Alert>
            )}

            {stats.needsMigration === 0 && (
              <Alert className="mt-4">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  All order items already have image data. No migration needed!
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Migration Actions */}
      {stats && stats.needsMigration > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Image className="h-5 w-5" />
              Migration Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex gap-4">
                <Button 
                  onClick={() => runMigration(true)}
                  disabled={loading}
                  variant="outline"
                  className="flex-1"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  Preview Migration
                </Button>
                <Button 
                  onClick={() => runMigration(false)}
                  disabled={loading}
                  className="flex-1"
                >
                  <Play className="h-4 w-4 mr-2" />
                  Run Migration
                </Button>
              </div>
              
              <div className="text-sm text-gray-600">
                <p><strong>Preview:</strong> Shows what changes will be made without modifying data.</p>
                <p><strong>Run:</strong> Executes the migration and updates order items with image data.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Migration Results */}
      {migrationResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {migrationResult.success ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <AlertTriangle className="h-5 w-5 text-red-600" />
              )}
              Migration {migrationResult.dryRun ? 'Preview' : 'Results'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Alert className={migrationResult.success ? '' : 'border-red-200'}>
              <AlertDescription>{migrationResult.message}</AlertDescription>
            </Alert>

            {migrationResult.dryRun && migrationResult.preview && (
              <div className="mt-4">
                <h4 className="font-medium mb-2">Preview Changes ({migrationResult.totalChanges} items):</h4>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {migrationResult.preview.slice(0, 5).map((change, index) => (
                    <div key={index} className="p-3 bg-gray-50 rounded text-sm">
                      <div className="font-medium">{change.name}</div>
                      <div className="text-gray-600">Sources: {change.sources.join(', ')}</div>
                      {change.proposed.design_image_url && (
                        <div className="text-xs text-blue-600 truncate">
                          Design: {change.proposed.design_image_url}
                        </div>
                      )}
                    </div>
                  ))}
                  {(migrationResult.totalChanges || 0) > 5 && (
                    <div className="text-sm text-gray-500 text-center">
                      ... and {(migrationResult.totalChanges || 0) - 5} more items
                    </div>
                  )}
                </div>
              </div>
            )}

            {migrationResult.results && (
              <div className="mt-4 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-green-50 rounded">
                    <div className="text-2xl font-bold text-green-600">
                      {migrationResult.results.updatedCount}
                    </div>
                    <div className="text-sm text-green-700">Items Updated</div>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded">
                    <div className="text-2xl font-bold text-blue-600">
                      +{migrationResult.results.improvement.designImages}
                    </div>
                    <div className="text-sm text-blue-700">Design Images Added</div>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded">
                    <div className="text-2xl font-bold text-purple-600">
                      +{migrationResult.results.improvement.productImages}
                    </div>
                    <div className="text-sm text-purple-700">Product Images Added</div>
                  </div>
                </div>

                {migrationResult.results.errorCount > 0 && (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      {migrationResult.results.errorCount} items failed to update. 
                      Check the console for details.
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Migration Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div>
              <strong>What this migration does:</strong>
              <ul className="list-disc list-inside mt-1 space-y-1 text-gray-600">
                <li>Extracts design images from customizations JSON data</li>
                <li>Populates design_image_url, product_image_url, and customized_image_url fields</li>
                <li>Links design files for operations team download</li>
                <li>Sets fallback placeholder images for items without data</li>
              </ul>
            </div>
            <div>
              <strong>Image sources (in priority order):</strong>
              <ul className="list-disc list-inside mt-1 space-y-1 text-gray-600">
                <li>AI Design preview URLs</li>
                <li>Custom design images</li>
                <li>Product base images</li>
                <li>Fallback placeholders</li>
              </ul>
            </div>
            <div>
              <strong>Safety:</strong>
              <span className="text-gray-600 ml-2">
                This migration only adds data to empty fields and never overwrites existing images.
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}