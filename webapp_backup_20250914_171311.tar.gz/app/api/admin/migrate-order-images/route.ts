import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/supabase'
import fs from 'fs'
import path from 'path'

export async function POST(request: NextRequest) {
  try {
    const { dryRun = false } = await request.json()
    
    // Check if user has admin permissions (you may want to add proper auth here)
    // const { data: { user } } = await supabase.auth.getUser()
    // if (!user || user.role !== 'admin') {
    //   return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    // }
    
    console.log('🚀 Starting order items image migration...', { dryRun })
    
    // Step 1: Analyze current state
    const { data: orderItems, error: fetchError } = await supabase
      .from('order_items')
      .select(`
        id,
        order_id,
        design_id,
        digital_product_id,
        name,
        customizations,
        design_image_url,
        product_image_url,
        customized_image_url,
        design_file_url,
        print_ready_file_url
      `)
    
    if (fetchError) {
      console.error('Failed to fetch order items:', fetchError)
      return NextResponse.json({ 
        error: 'Failed to fetch order items', 
        details: fetchError.message 
      }, { status: 500 })
    }
    
    const stats = {
      total: orderItems.length,
      withDesignImages: orderItems.filter(item => item.design_image_url).length,
      withProductImages: orderItems.filter(item => item.product_image_url).length,
      withCustomizedImages: orderItems.filter(item => item.customized_image_url).length,
      withDesignFiles: orderItems.filter(item => item.design_file_url).length,
      withCustomizations: orderItems.filter(item => item.customizations).length,
      withDesignId: orderItems.filter(item => item.design_id).length,
      withDigitalProductId: orderItems.filter(item => item.digital_product_id).length,
      needsMigration: orderItems.filter(item => 
        !item.design_image_url && 
        (item.customizations || item.design_id || item.digital_product_id)
      ).length
    }
    
    console.log('📊 Current state analysis:', stats)
    
    if (stats.needsMigration === 0) {
      return NextResponse.json({
        success: true,
        message: 'No migration needed - all order items already have image data!',
        stats
      })
    }
    
    // Step 2: Preview what will be migrated
    const itemsToMigrate = orderItems.filter(item => 
      !item.design_image_url && 
      (item.customizations || item.design_id || item.digital_product_id)
    )
    
    const migrationPreview = itemsToMigrate.map(item => {
      const changes = {
        id: item.id,
        name: item.name,
        proposed: {
          design_image_url: null as string | null,
          product_image_url: null as string | null,
          customized_image_url: null as string | null,
          design_file_url: null as string | null,
          print_ready_file_url: null as string | null
        },
        sources: [] as string[]
      }
      
      if (item.customizations) {
        const customizations = item.customizations as any
        
        // Design image sources
        if (customizations.aiDesign?.previewUrl) {
          changes.proposed.design_image_url = customizations.aiDesign.previewUrl
          changes.sources.push('aiDesign.previewUrl')
        } else if (customizations.customDesign?.customizedProductImage) {
          changes.proposed.design_image_url = customizations.customDesign.customizedProductImage
          changes.sources.push('customDesign.customizedProductImage')
        } else if (customizations.preview_url) {
          changes.proposed.design_image_url = customizations.preview_url
          changes.sources.push('preview_url')
        } else if (customizations.customizedProductImage) {
          changes.proposed.design_image_url = customizations.customizedProductImage
          changes.sources.push('customizedProductImage')
        }
        
        // Product image sources
        if (customizations.product?.image) {
          changes.proposed.product_image_url = customizations.product.image
          changes.sources.push('product.image')
        }
        
        // Customized image sources
        if (customizations.customDesign?.customizedProductImage) {
          changes.proposed.customized_image_url = customizations.customDesign.customizedProductImage
          changes.sources.push('customDesign.customizedProductImage')
        } else if (customizations.aiDesign?.previewUrl) {
          changes.proposed.customized_image_url = customizations.aiDesign.previewUrl
          changes.sources.push('aiDesign.previewUrl')
        }
      }
      
      return changes
    }).filter(change => change.sources.length > 0)
    
    if (dryRun) {
      return NextResponse.json({
        success: true,
        dryRun: true,
        message: `Migration preview completed. ${migrationPreview.length} items can be migrated.`,
        stats,
        preview: migrationPreview.slice(0, 10), // Return first 10 for preview
        totalChanges: migrationPreview.length
      })
    }
    
    // Step 3: Execute migration
    console.log('🔄 Executing migration...')
    
    let updatedCount = 0
    const errors = []
    
    // Process items in batches to avoid overwhelming the database
    const batchSize = 50
    for (let i = 0; i < migrationPreview.length; i += batchSize) {
      const batch = migrationPreview.slice(i, i + batchSize)
      
      for (const change of batch) {
        try {
          const updateData: any = {}
          
          if (change.proposed.design_image_url) {
            updateData.design_image_url = change.proposed.design_image_url
          }
          if (change.proposed.product_image_url) {
            updateData.product_image_url = change.proposed.product_image_url
          }
          if (change.proposed.customized_image_url) {
            updateData.customized_image_url = change.proposed.customized_image_url
          }
          
          // Also set design_file_url and print_ready_file_url if not already set
          if (!change.proposed.design_file_url && change.proposed.design_image_url) {
            updateData.design_file_url = change.proposed.design_image_url
          }
          if (!change.proposed.print_ready_file_url && change.proposed.design_image_url) {
            updateData.print_ready_file_url = change.proposed.design_image_url
          }
          
          if (Object.keys(updateData).length > 0) {
            const { error: updateError } = await supabase
              .from('order_items')
              .update(updateData)
              .eq('id', change.id)
            
            if (updateError) {
              errors.push({ id: change.id, error: updateError.message })
            } else {
              updatedCount++
            }
          }
        } catch (error: any) {
          errors.push({ id: change.id, error: error?.message || 'Unknown error' })
        }
      }
    }
    
    // Step 4: Set fallback placeholders for remaining items
    const { error: placeholderError } = await supabase
      .from('order_items')
      .update({ 
        design_image_url: '/placeholder.svg?height=200&width=200&text=Design',
        product_image_url: '/placeholder.svg?height=200&width=200&text=Product'
      })
      .is('design_image_url', null)
      .not('design_id', 'is', null)
    
    if (placeholderError) {
      console.warn('Failed to set placeholder images:', placeholderError)
    }
    
    // Step 5: Get final stats
    const { data: finalOrderItems } = await supabase
      .from('order_items')
      .select('design_image_url, product_image_url, customized_image_url')
    
    const finalStats = {
      total: finalOrderItems?.length || 0,
      withDesignImages: finalOrderItems?.filter(item => item.design_image_url).length || 0,
      withProductImages: finalOrderItems?.filter(item => item.product_image_url).length || 0,
      withCustomizedImages: finalOrderItems?.filter(item => item.customized_image_url).length || 0
    }
    
    console.log('✅ Migration completed:', {
      updatedCount,
      errors: errors.length,
      finalStats
    })
    
    return NextResponse.json({
      success: true,
      message: `Migration completed successfully! Updated ${updatedCount} order items.`,
      results: {
        updatedCount,
        errorCount: errors.length,
        errors: errors.slice(0, 5), // Return first 5 errors
        beforeStats: stats,
        afterStats: finalStats,
        improvement: {
          designImages: finalStats.withDesignImages - stats.withDesignImages,
          productImages: finalStats.withProductImages - stats.withProductImages,
          customizedImages: finalStats.withCustomizedImages - stats.withCustomizedImages
        }
      }
    })
    
  } catch (error: any) {
    console.error('Migration failed:', error)
    return NextResponse.json({ 
      error: 'Migration failed', 
      details: error?.message || 'Unknown error' 
    }, { status: 500 })
  }
}

export async function GET() {
  try {
    // Return current migration status
    const { data: orderItems, error } = await supabase
      .from('order_items')
      .select('design_image_url, product_image_url, customized_image_url, design_id, digital_product_id, customizations')
    
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }
    
    const stats = {
      total: orderItems.length,
      withDesignImages: orderItems.filter(item => item.design_image_url).length,
      withProductImages: orderItems.filter(item => item.product_image_url).length,
      withCustomizedImages: orderItems.filter(item => item.customized_image_url).length,
      needsMigration: orderItems.filter(item => 
        !item.design_image_url && 
        (item.customizations || item.design_id || item.digital_product_id)
      ).length
    }
    
    return NextResponse.json({
      stats,
      migrationNeeded: stats.needsMigration > 0,
      coverage: {
        designImages: `${(stats.withDesignImages/stats.total*100).toFixed(1)}%`,
        productImages: `${(stats.withProductImages/stats.total*100).toFixed(1)}%`,
        customizedImages: `${(stats.withCustomizedImages/stats.total*100).toFixed(1)}%`
      }
    })
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Unknown error' }, { status: 500 })
  }
}