# Order Items Image Migration Guide

## Overview

This migration is designed to populate image URLs for existing order items that were created before the new image system was implemented. It extracts image data from customizations JSON and related tables to populate the new image URL columns.

## Problem Statement

Older orders in the system show "No items found for this order" because:
- Order items were created without image URL fields
- Design images were stored only in customizations JSON
- The new order display system expects dedicated image URL fields
- Operations team needs direct access to design files

## Solution

The migration extracts image URLs from various sources and populates the following fields:
- `design_image_url` - Customer's design thumbnail
- `product_image_url` - Base product/material image
- `customized_image_url` - Final customized product preview
- `design_file_url` - Print-ready file for operations
- `print_ready_file_url` - Production download link

## Migration Methods

### Method 1: Admin Interface (Recommended)

1. **Access the Admin Panel**
   ```
   http://localhost:3001/admin/migrate-images
   ```

2. **Preview Migration**
   - Click "Preview Migration" to see what changes will be made
   - Review the items that will be updated
   - Check the image sources and URLs

3. **Run Migration**
   - Click "Run Migration" to execute the changes
   - Monitor the progress and results
   - Verify the improvement statistics

### Method 2: API Endpoint

**Preview Migration:**
```bash
curl -X POST http://localhost:3001/api/admin/migrate-order-images \
  -H "Content-Type: application/json" \
  -d '{"dryRun": true}'
```

**Execute Migration:**
```bash
curl -X POST http://localhost:3001/api/admin/migrate-order-images \
  -H "Content-Type: application/json" \
  -d '{"dryRun": false}'
```

**Check Status:**
```bash
curl http://localhost:3001/api/admin/migrate-order-images
```

### Method 3: Command Line Script

**Preview Migration:**
```bash
node scripts/migrate-order-images.js --dry-run --verbose
```

**Execute Migration:**
```bash
node scripts/migrate-order-images.js --verbose
```

### Method 4: Direct SQL Migration

**Run the SQL migration file:**
```sql
-- Execute the migration file
\i supabase/migrations/migrate_order_items_images.sql
```

## Image Source Priority

The migration extracts images from the following sources in priority order:

### Design Images (`design_image_url`)
1. `customizations.aiDesign.previewUrl` - AI-generated design previews
2. `customizations.customDesign.customizedProductImage` - Custom design images
3. `customizations.preview_url` - General preview URLs
4. `customizations.customizedProductImage` - Legacy customized images
5. `customizations.designUrl` - Design file URLs
6. `customizations.storageUrl` - Storage URLs
7. `digital_products.preview_url` - From digital products table
8. `designs.thumbnail_url` - From designs table
9. Fallback placeholder: `/placeholder.svg?height=200&width=200&text=Design`

### Product Images (`product_image_url`)
1. `customizations.product.image` - Base product images
2. Fallback placeholder: `/placeholder.svg?height=200&width=200&text=Product`

### Customized Images (`customized_image_url`)
1. `customizations.customDesign.customizedProductImage` - Final custom designs
2. `customizations.aiDesign.previewUrl` - AI design previews
3. `customizations.customizedProductImage` - Legacy customized images

## Migration Process

The migration follows these steps:

1. **Analysis Phase**
   - Count total order items
   - Identify items with missing images
   - Calculate current coverage percentages

2. **Extraction Phase**
   - Parse customizations JSON for image URLs
   - Query related tables (digital_products, designs)
   - Validate and clean image URLs

3. **Update Phase**
   - Update order items with extracted images
   - Set design and production file URLs
   - Apply fallback placeholders where needed

4. **Verification Phase**
   - Recalculate coverage statistics
   - Generate migration report
   - Create performance indexes

## Expected Results

### Before Migration
```
Order #ORD-175754956309:
- "No items found for this order"
- Missing design thumbnails
- No production files for operations
```

### After Migration
```
Order #ORD-175754956309:
- Order Items with Design Thumbnails:
  * BOND - 8.5" × 11" (single-sided)
    - Design Preview: [Custom Design Image]
    - Material: BOND paper
    - Production File: [Download Link]
```

## Safety Measures

### Data Protection
- **Non-destructive**: Only populates empty fields, never overwrites existing data
- **Reversible**: Original customizations JSON is preserved
- **Idempotent**: Can be run multiple times safely
- **Transactional**: Uses database transactions for consistency

### Validation
- **URL Validation**: Checks image URL format and accessibility
- **Data Integrity**: Validates JSON structure before extraction
- **Error Handling**: Continues processing if individual items fail
- **Logging**: Comprehensive logging for troubleshooting

## Monitoring and Verification

### Check Migration Status
```sql
SELECT 
    COUNT(*) as total_items,
    COUNT(design_image_url) as with_design_images,
    COUNT(product_image_url) as with_product_images,
    COUNT(customized_image_url) as with_customized_images,
    ROUND(COUNT(design_image_url)::float / COUNT(*) * 100, 1) as design_coverage_pct
FROM order_items;
```

### Verify Specific Order
```sql
SELECT 
    id,
    name,
    design_image_url,
    product_image_url,
    customized_image_url,
    design_file_url
FROM order_items 
WHERE order_id = 'your-order-id';
```

### Check Image Accessibility
```sql
SELECT 
    design_image_url,
    COUNT(*) as count
FROM order_items 
WHERE design_image_url IS NOT NULL
GROUP BY design_image_url
ORDER BY count DESC
LIMIT 10;
```

## Troubleshooting

### Common Issues

**1. No Images Found**
- Check if customizations JSON contains image data
- Verify design_id and digital_product_id references
- Ensure related tables have image URLs

**2. Broken Image URLs**
- Validate image URL accessibility
- Check Supabase storage permissions
- Verify image file existence

**3. Migration Fails**
- Check database permissions
- Verify JSON structure validity
- Review error logs for specific failures

### Recovery Steps

**Rollback (if needed):**
```sql
-- Reset image URLs to NULL (use with caution)
UPDATE order_items 
SET design_image_url = NULL,
    product_image_url = NULL,
    customized_image_url = NULL,
    design_file_url = NULL,
    print_ready_file_url = NULL
WHERE updated_at > 'migration-timestamp';
```

**Re-run Migration:**
- The migration is idempotent and can be safely re-run
- Use dry-run mode first to preview changes
- Monitor progress and error logs

## Performance Considerations

### Database Impact
- **Batch Processing**: Updates are processed in batches of 50 items
- **Indexes**: Creates indexes on image URL columns for better performance
- **Memory Usage**: Minimal memory footprint with streaming processing
- **Execution Time**: Approximately 1-2 seconds per 100 order items

### Optimization
- Run during low-traffic periods
- Monitor database CPU and memory usage
- Consider running in smaller batches for large datasets
- Use connection pooling for better performance

## Post-Migration Tasks

1. **Verify Order Display**
   - Check order pages show design thumbnails
   - Verify download links work for operations
   - Test image loading performance

2. **Update Documentation**
   - Update order management procedures
   - Train operations team on new download features
   - Update customer service scripts

3. **Monitor Performance**
   - Track image loading times
   - Monitor storage bandwidth usage
   - Check for broken image links

## Support

For issues or questions about the migration:
1. Check the migration logs for error details
2. Verify database permissions and connectivity
3. Review the customizations JSON structure
4. Test with a small subset of orders first

---

**Migration Status**: Ready for execution
**Estimated Impact**: High - Significantly improves order visibility and operations workflow
**Risk Level**: Low - Non-destructive, reversible changes
**Execution Time**: 5-15 minutes depending on order volume