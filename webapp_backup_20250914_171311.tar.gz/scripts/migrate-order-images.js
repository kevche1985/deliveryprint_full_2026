#!/usr/bin/env node

/**
 * Order Items Image Migration Script
 * 
 * This script migrates image data for existing order items that were created
 * before the new image URL system was implemented. It extracts image URLs
 * from customizations JSON and related tables to populate the new image columns.
 * 
 * Usage:
 *   node scripts/migrate-order-images.js [--dry-run] [--verbose]
 * 
 * Options:
 *   --dry-run    Show what would be migrated without making changes
 *   --verbose    Show detailed progress information
 */

const { createClient } = require('@supabase/supabase-js')
const fs = require('fs')
const path = require('path')

// Load environment variables
require('dotenv').config()

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Missing required environment variables:')
  console.error('   NEXT_PUBLIC_SUPABASE_URL')
  console.error('   SUPABASE_SERVICE_ROLE_KEY')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseServiceKey)

// Parse command line arguments
const args = process.argv.slice(2)
const isDryRun = args.includes('--dry-run')
const isVerbose = args.includes('--verbose')

function log(message, force = false) {
  if (isVerbose || force) {
    console.log(message)
  }
}

function logError(message) {
  console.error(`❌ ${message}`)
}

function logSuccess(message) {
  console.log(`✅ ${message}`)
}

function logWarning(message) {
  console.log(`⚠️  ${message}`)
}

function logInfo(message) {
  console.log(`ℹ️  ${message}`)
}

async function analyzeCurrentState() {
  logInfo('Analyzing current order items state...')
  
  const { data: orderItems, error } = await supabase
    .from('order_items')
    .select(`
      id,
      order_id,
      design_id,
      digital_product_id,
      name,
      customizations,
      design_image_url,
      product_image_url,
      customized_image_url,
      design_file_url,
      print_ready_file_url
    `)
  
  if (error) {
    logError(`Failed to fetch order items: ${error.message}`)
    return null
  }
  
  const stats = {
    total: orderItems.length,
    withDesignImages: orderItems.filter(item => item.design_image_url).length,
    withProductImages: orderItems.filter(item => item.product_image_url).length,
    withCustomizedImages: orderItems.filter(item => item.customized_image_url).length,
    withDesignFiles: orderItems.filter(item => item.design_file_url).length,
    withCustomizations: orderItems.filter(item => item.customizations).length,
    withDesignId: orderItems.filter(item => item.design_id).length,
    withDigitalProductId: orderItems.filter(item => item.digital_product_id).length,
    needsMigration: orderItems.filter(item => 
      !item.design_image_url && 
      (item.customizations || item.design_id || item.digital_product_id)
    ).length
  }
  
  console.log('\n📊 Current Order Items Analysis:')
  console.log(`   Total order items: ${stats.total}`)
  console.log(`   With design images: ${stats.withDesignImages} (${(stats.withDesignImages/stats.total*100).toFixed(1)}%)`)
  console.log(`   With product images: ${stats.withProductImages} (${(stats.withProductImages/stats.total*100).toFixed(1)}%)`)
  console.log(`   With customized images: ${stats.withCustomizedImages} (${(stats.withCustomizedImages/stats.total*100).toFixed(1)}%)`)
  console.log(`   With design files: ${stats.withDesignFiles} (${(stats.withDesignFiles/stats.total*100).toFixed(1)}%)`)
  console.log(`   With customizations: ${stats.withCustomizations} (${(stats.withCustomizations/stats.total*100).toFixed(1)}%)`)
  console.log(`   With design ID: ${stats.withDesignId} (${(stats.withDesignId/stats.total*100).toFixed(1)}%)`)
  console.log(`   With digital product ID: ${stats.withDigitalProductId} (${(stats.withDigitalProductId/stats.total*100).toFixed(1)}%)`)
  console.log(`   Need migration: ${stats.needsMigration} (${(stats.needsMigration/stats.total*100).toFixed(1)}%)`)
  
  return { orderItems, stats }
}

async function previewMigration(orderItems) {
  logInfo('Previewing migration changes...')
  
  const changes = []
  
  for (const item of orderItems) {
    if (item.design_image_url) continue // Already has image
    
    const change = {
      id: item.id,
      name: item.name,
      current: {
        design_image_url: item.design_image_url,
        product_image_url: item.product_image_url,
        customized_image_url: item.customized_image_url
      },
      proposed: {
        design_image_url: null,
        product_image_url: null,
        customized_image_url: null
      },
      sources: []
    }
    
    // Check customizations for image URLs
    if (item.customizations) {
      const customizations = item.customizations
      
      // Design image sources
      if (customizations.aiDesign?.previewUrl) {
        change.proposed.design_image_url = customizations.aiDesign.previewUrl
        change.sources.push('customizations.aiDesign.previewUrl')
      } else if (customizations.customDesign?.customizedProductImage) {
        change.proposed.design_image_url = customizations.customDesign.customizedProductImage
        change.sources.push('customizations.customDesign.customizedProductImage')
      } else if (customizations.preview_url) {
        change.proposed.design_image_url = customizations.preview_url
        change.sources.push('customizations.preview_url')
      } else if (customizations.customizedProductImage) {
        change.proposed.design_image_url = customizations.customizedProductImage
        change.sources.push('customizations.customizedProductImage')
      }
      
      // Product image sources
      if (customizations.product?.image) {
        change.proposed.product_image_url = customizations.product.image
        change.sources.push('customizations.product.image')
      }
      
      // Customized image sources
      if (customizations.customDesign?.customizedProductImage) {
        change.proposed.customized_image_url = customizations.customDesign.customizedProductImage
        change.sources.push('customizations.customDesign.customizedProductImage (customized)')
      } else if (customizations.aiDesign?.previewUrl) {
        change.proposed.customized_image_url = customizations.aiDesign.previewUrl
        change.sources.push('customizations.aiDesign.previewUrl (customized)')
      }
    }
    
    if (change.sources.length > 0) {
      changes.push(change)
    }
  }
  
  console.log(`\n🔍 Migration Preview (${changes.length} items will be updated):`)
  
  if (isVerbose && changes.length > 0) {
    changes.slice(0, 5).forEach((change, index) => {
      console.log(`\n   ${index + 1}. ${change.name} (ID: ${change.id})`)
      console.log(`      Sources: ${change.sources.join(', ')}`)
      if (change.proposed.design_image_url) {
        console.log(`      Design Image: ${change.proposed.design_image_url.substring(0, 60)}...`)
      }
      if (change.proposed.product_image_url) {
        console.log(`      Product Image: ${change.proposed.product_image_url.substring(0, 60)}...`)
      }
    })
    
    if (changes.length > 5) {
      console.log(`   ... and ${changes.length - 5} more items`)
    }
  }
  
  return changes
}

async function runMigration() {
  logInfo('Running migration...')
  
  // Read the migration SQL file
  const migrationPath = path.join(__dirname, '..', 'supabase', 'migrations', 'migrate_order_items_images.sql')
  
  if (!fs.existsSync(migrationPath)) {
    logError(`Migration file not found: ${migrationPath}`)
    return false
  }
  
  const migrationSQL = fs.readFileSync(migrationPath, 'utf8')
  
  try {
    // Execute the migration
    const { error } = await supabase.rpc('exec_sql', { sql: migrationSQL })
    
    if (error) {
      logError(`Migration failed: ${error.message}`)
      return false
    }
    
    logSuccess('Migration completed successfully!')
    return true
  } catch (error) {
    logError(`Migration failed: ${error.message}`)
    return false
  }
}

async function main() {
  console.log('🚀 Order Items Image Migration Tool\n')
  
  if (isDryRun) {
    logWarning('DRY RUN MODE - No changes will be made')
  }
  
  // Step 1: Analyze current state
  const analysis = await analyzeCurrentState()
  if (!analysis) {
    process.exit(1)
  }
  
  const { orderItems, stats } = analysis
  
  if (stats.needsMigration === 0) {
    logSuccess('No migration needed - all order items already have image data!')
    process.exit(0)
  }
  
  // Step 2: Preview migration
  const changes = await previewMigration(orderItems.filter(item => 
    !item.design_image_url && 
    (item.customizations || item.design_id || item.digital_product_id)
  ))
  
  if (changes.length === 0) {
    logWarning('No changes can be made with available data')
    process.exit(0)
  }
  
  // Step 3: Run migration (if not dry run)
  if (!isDryRun) {
    console.log('\n⚠️  This will modify your database. Continue? (y/N)')
    
    const readline = require('readline')
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    })
    
    const answer = await new Promise(resolve => {
      rl.question('', resolve)
    })
    rl.close()
    
    if (answer.toLowerCase() !== 'y' && answer.toLowerCase() !== 'yes') {
      logInfo('Migration cancelled')
      process.exit(0)
    }
    
    const success = await runMigration()
    
    if (success) {
      // Re-analyze to show results
      const finalAnalysis = await analyzeCurrentState()
      if (finalAnalysis) {
        console.log('\n🎉 Migration Results:')
        const improvement = finalAnalysis.stats.withDesignImages - stats.withDesignImages
        console.log(`   Design images added: ${improvement}`)
        console.log(`   Total coverage: ${(finalAnalysis.stats.withDesignImages/finalAnalysis.stats.total*100).toFixed(1)}%`)
      }
    } else {
      process.exit(1)
    }
  } else {
    logInfo('Dry run completed - use without --dry-run to execute migration')
  }
}

// Handle errors
process.on('unhandledRejection', (error) => {
  logError(`Unhandled error: ${error.message}`)
  process.exit(1)
})

// Run the script
main().catch(error => {
  logError(`Script failed: ${error.message}`)
  process.exit(1)
})