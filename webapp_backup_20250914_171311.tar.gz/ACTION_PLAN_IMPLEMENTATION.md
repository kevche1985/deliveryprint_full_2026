# 🚀 ACTION PLAN: CRITICAL ISSUES RESOLUTION
**Print-on-Demand Platform - Emergency Fix Implementation**

**Date:** January 10, 2025  
**Priority:** 🔴 CRITICAL - Immediate Implementation Required  
**Timeline:** 6 weeks (4 sprints)  
**Team:** Full development team mobilization  

---

## 📋 PHASE 0: BACKUP AND PREPARATION (Day 1)

### **🛡️ STEP 1: Create Complete System Backup**
**Duration:** 2 hours  
**Responsible:** DevOps Team  
**Priority:** 🔴 CRITICAL

#### **Database Backup**
```bash
# Create Supabase database backup
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d_%H%M%S).sql

# Export current schema
supabase db dump --schema-only > schema_backup_$(date +%Y%m%d).sql

# Export current data
supabase db dump --data-only > data_backup_$(date +%Y%m%d).sql
```

#### **Codebase Backup**
```bash
# Create Git backup branch
git checkout -b backup-before-critical-fixes
git add .
git commit -m "BACKUP: Complete system state before critical fixes"
git push origin backup-before-critical-fixes

# Create compressed archive
tar -czf webapp_backup_$(date +%Y%m%d).tar.gz .
```

#### **Environment Configuration Backup**
```bash
# Backup environment variables
cp .env .env.backup.$(date +%Y%m%d)
cp .env.local .env.local.backup.$(date +%Y%m%d)

# Document current Supabase configuration
supabase status > supabase_status_backup.txt
```

### **🔧 STEP 2: Development Environment Setup**
**Duration:** 1 hour  
**Responsible:** All Teams  

#### **Team Coordination Setup**
```bash
# Create feature branches for each critical task
git checkout -b fix/authentication-system
git checkout -b fix/database-schema
git checkout -b fix/order-creation
git checkout -b fix/product-catalog
git checkout -b fix/cart-functionality
```

#### **Development Tools Setup**
```bash
# Install dependencies
npm install

# Verify development server
npm run dev

# Test database connection
npx supabase status
```

---

## 🔥 PHASE 1: CRITICAL BLOCKERS (Week 1 - Sprint 1)
**Goal:** Make system functional for basic testing  
**Duration:** 5 days (40 hours)  
**Success Criteria:** Users can register, login, browse products, add to cart, and create orders

### **🔐 TASK-001: Fix Authentication System**
**Priority:** 🔴 CRITICAL  
**Duration:** Day 1-2 (8 hours)  
**Team:** Backend (4h) + Frontend (4h)  
**Branch:** `fix/authentication-system`

#### **Backend Implementation (4 hours)**
```typescript
// 1. Fix Supabase Configuration (1 hour)
// File: lib/supabase.ts
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
})

// 2. Create Test Users (1 hour)
// SQL Script: supabase/seed/test_users.sql
INSERT INTO auth.users (id, email, encrypted_password, email_confirmed_at, created_at, updated_at)
VALUES 
  ('11111111-1111-1111-1111-111111111111', 'admin@test.com', crypt('admin123', gen_salt('bf')), now(), now(), now()),
  ('22222222-2222-2222-2222-222222222222', 'customer@test.com', crypt('customer123', gen_salt('bf')), now(), now(), now()),
  ('33333333-3333-3333-3333-333333333333', 'operator@test.com', crypt('operator123', gen_salt('bf')), now(), now(), now());

// 3. Fix RLS Policies (2 hours)
// File: supabase/migrations/fix_auth_policies.sql
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);
```

#### **Frontend Implementation (4 hours)**
```typescript
// 1. Fix Auth Context (2 hours)
// File: lib/auth-context.tsx
'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { User } from '@supabase/supabase-js'
import { supabase } from './supabase'

interface AuthContextType {
  user: User | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<any>
  signUp: (email: string, password: string) => Promise<any>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null)
      setLoading(false)
    })

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null)
        setLoading(false)
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })
    return { data, error }
  }

  const signUp = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password
    })
    return { data, error }
  }

  const signOut = async () => {
    await supabase.auth.signOut()
  }

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

// 2. Fix Login/Register Forms (2 hours)
// File: app/auth/login/page.tsx
'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const { signIn } = useAuth()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const { error } = await signIn(email, password)
      if (error) {
        toast.error(error.message)
      } else {
        toast.success('Logged in successfully!')
        router.push('/dashboard')
      }
    } catch (error) {
      toast.error('An unexpected error occurred')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto mt-8 p-6 bg-white rounded-lg shadow-md">
      <h1 className="text-2xl font-bold mb-6">Login</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <Input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <Button type="submit" disabled={loading} className="w-full">
          {loading ? 'Logging in...' : 'Login'}
        </Button>
      </form>
    </div>
  )
}
```

#### **Testing Checklist**
- [ ] User can register new account
- [ ] User receives confirmation email
- [ ] User can login with valid credentials
- [ ] Authentication state persists across page refreshes
- [ ] Password reset functionality works
- [ ] Role-based access control functional

---

### **🗄️ TASK-002: Database Schema and Seed Data**
**Priority:** 🔴 CRITICAL  
**Duration:** Day 2 (6 hours)  
**Team:** Backend (6h)  
**Branch:** `fix/database-schema`

#### **Database Migrations (3 hours)**
```sql
-- File: supabase/migrations/add_foreign_keys.sql
-- Add foreign key constraints
ALTER TABLE order_items 
ADD CONSTRAINT fk_order_items_order_id 
FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE;

ALTER TABLE order_items 
ADD CONSTRAINT fk_order_items_product_id 
FOREIGN KEY (product_id) REFERENCES products(id);

ALTER TABLE orders 
ADD CONSTRAINT fk_orders_user_id 
FOREIGN KEY (user_id) REFERENCES auth.users(id);

-- File: supabase/migrations/implement_rls_policies.sql
-- Enable RLS on all tables
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create own orders" ON orders
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Everyone can view products" ON products
  FOR SELECT USING (true);

CREATE POLICY "Admins can manage products" ON products
  FOR ALL USING (auth.jwt() ->> 'role' = 'admin');
```

#### **Seed Data Creation (3 hours)**
```sql
-- File: supabase/seed/products.sql
INSERT INTO categories (id, name, slug, description, is_active) VALUES
  ('cat-001', 'Business Cards', 'business-cards', 'Professional business cards', true),
  ('cat-002', 'Flyers', 'flyers', 'Marketing flyers and brochures', true),
  ('cat-003', 'Banners', 'banners', 'Large format banners', true),
  ('cat-004', 'Digital Products', 'digital-products', 'Digital downloads', true);

INSERT INTO products (id, name, description, price, category_id, image, is_active, is_featured) VALUES
  ('prod-001', 'FOLDCOTE 14 - 8.5" × 11" (single-sided)', 'High-quality foldcote paper printing', 0.75, 'cat-002', '/images/products/foldcote.jpg', true, true),
  ('prod-002', 'BOND - 8.5" × 11" (single-sided)', 'Standard bond paper printing', 0.50, 'cat-002', '/images/products/bond.jpg', true, true),
  ('prod-003', 'ADHESIVO - 8.5" × 11"', 'Adhesive sticker printing', 1.25, 'cat-002', '/images/products/adhesivo.jpg', true, false),
  ('prod-004', 'Business Card - Standard', 'Professional business cards', 25.00, 'cat-001', '/images/products/business-card.jpg', true, true),
  ('prod-005', 'Banner - Large Format', 'Custom large format banners', 45.00, 'cat-003', '/images/products/banner.jpg', true, false);

INSERT INTO product_variants (id, product_id, name, sku, price, attributes) VALUES
  ('var-001', 'prod-001', 'Single-sided', 'FOLD-SS', 0.75, '{"sides": "single", "size": "8.5x11"}'),
  ('var-002', 'prod-001', 'Double-sided', 'FOLD-DS', 1.25, '{"sides": "double", "size": "8.5x11"}'),
  ('var-003', 'prod-002', 'Single-sided', 'BOND-SS', 0.50, '{"sides": "single", "size": "8.5x11"}'),
  ('var-004', 'prod-002', 'Double-sided', 'BOND-DS', 0.85, '{"sides": "double", "size": "8.5x11"}');
```

#### **Testing Checklist**
- [ ] All migrations execute successfully
- [ ] Foreign key constraints are in place
- [ ] RLS policies are functional
- [ ] Seed data is properly inserted
- [ ] Database integrity is maintained

---

### **🛒 TASK-003: Fix Order Creation System**
**Priority:** 🔴 CRITICAL  
**Duration:** Day 3-4 (10 hours)  
**Team:** Backend (6h) + Frontend (4h)  
**Branch:** `fix/order-creation`

#### **Backend Implementation (6 hours)**
```typescript
// File: lib/database.ts - Enhanced order creation
export async function createOrder(orderData: {
  user_id: string
  email: string
  total: number
  shipping_address: any
  billing_address: any
  payment_method: string
  payment_status: string
}) {
  try {
    // Generate unique order number
    const orderNumber = `ORD-${Date.now()}`
    
    const { data, error } = await supabase
      .from('orders')
      .insert({
        ...orderData,
        order_number: orderNumber,
        status: 'pending',
        created_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) {
      console.error('Order creation error:', error)
      throw error
    }
    
    console.log('Order created successfully:', data)
    return data
  } catch (error) {
    console.error('Failed to create order:', error)
    throw error
  }
}

export async function createOrderItems(orderId: string, cartItems: any[]) {
  try {
    const orderItems = cartItems.map(item => ({
      order_id: orderId,
      product_id: item.productId,
      variant_id: item.variantId || null,
      design_id: item.designId || null,
      quantity: item.quantity || 1,
      price: item.price || 0,
      name: item.name,
      // Image URL mapping
      product_image_url: item.customizations?.product?.image || null,
      design_image_url: item.image || null, // Design preview
      customized_image_url: item.customizations?.customDesign?.customizedProductImage || 
                           item.customizations?.aiDesign?.previewUrl || null,
      design_file_url: item.customizations?.customDesign?.customizedProductImage || 
                      item.customizations?.aiDesign?.previewUrl || null,
      print_ready_file_url: item.customizations?.customDesign?.customizedProductImage || 
                           item.customizations?.aiDesign?.previewUrl || null,
      customizations: item.customizations || {}
    }))
    
    const { data, error } = await supabase
      .from('order_items')
      .insert(orderItems)
      .select()
    
    if (error) {
      console.error('Order items creation error:', error)
      throw error
    }
    
    console.log('Order items created successfully:', data)
    return data
  } catch (error) {
    console.error('Failed to create order items:', error)
    throw error
  }
}

// File: app/api/payments/confirm/route.ts - Fixed payment confirmation
export async function POST(request: NextRequest) {
  try {
    const { orderId, cartItems, digitalCartItems, transactionId, total, customerEmail, shippingAddress } = await request.json()
    
    console.log('Payment confirmation started:', { orderId, transactionId })
    
    // Update order payment status
    const { data: updatedOrder, error: orderError } = await supabase
      .from('orders')
      .update({ 
        payment_status: 'completed',
        transaction_id: transactionId,
        updated_at: new Date().toISOString()
      })
      .eq('id', orderId)
      .select()
      .single()
    
    if (orderError) {
      console.error('Failed to update order:', orderError)
      throw orderError
    }
    
    // Create order items with proper image mapping
    if (cartItems && cartItems.length > 0) {
      const orderItems = await createOrderItems(orderId, cartItems)
      console.log('Order items created:', orderItems.length)
    }
    
    // Send order confirmation email
    try {
      await sendOrderConfirmationEmail({
        customerEmail: customerEmail || 'customer@example.com',
        customerName: shippingAddress?.firstName || 'Customer',
        orderNumber: updatedOrder.order_number,
        orderTotal: total?.toString() || '0.00',
        orderItems: cartItems.map((item: any) => ({
          name: item.name || 'Item',
          quantity: item.quantity || 1,
          price: (item.price || 0).toString()
        }))
      })
    } catch (emailError) {
      console.error('Failed to send confirmation email:', emailError)
      // Don't fail the entire process for email issues
    }
    
    return NextResponse.json({
      success: true,
      order: updatedOrder,
      message: 'Payment confirmed and order updated successfully'
    })
    
  } catch (error: any) {
    console.error('Payment confirmation failed:', error)
    return NextResponse.json(
      { error: 'Payment confirmation failed', details: error.message },
      { status: 500 }
    )
  }
}
```

#### **Frontend Implementation (4 hours)**
```typescript
// File: app/checkout/page.tsx - Enhanced checkout process
const handlePayPalSuccess = async (details: any) => {
  try {
    setProcessingPayment(true)
    
    // Create order first
    const orderData = {
      user_id: user?.id || 'anonymous',
      email: user?.email || formData.email,
      total: cartTotal,
      shipping_address: formData.shippingAddress,
      billing_address: formData.billingAddress,
      payment_method: 'paypal',
      payment_status: 'pending'
    }
    
    const order = await createOrder(orderData)
    console.log('Order created:', order)
    
    // Confirm payment with order items
    const response = await fetch('/api/payments/confirm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        orderId: order.id,
        cartItems: cartItems,
        digitalCartItems: digitalCartItems,
        transactionId: details.id,
        total: cartTotal,
        customerEmail: user?.email || formData.email,
        shippingAddress: formData.shippingAddress
      })
    })
    
    const result = await response.json()
    
    if (result.success) {
      toast.success('Order created successfully!')
      clearCart()
      clearDigitalCart()
      router.push(`/orders/${order.id}/confirmation`)
    } else {
      throw new Error(result.error || 'Payment confirmation failed')
    }
    
  } catch (error: any) {
    console.error('Checkout error:', error)
    toast.error(error.message || 'Checkout failed')
  } finally {
    setProcessingPayment(false)
  }
}
```

#### **Testing Checklist**
- [ ] Orders are created and persisted to database
- [ ] Order items are created with proper image URLs
- [ ] Payment confirmation updates order status
- [ ] Order confirmation emails are sent
- [ ] Orders appear in user dashboard
- [ ] Admin can view and manage orders

---

### **📦 TASK-004: Product Catalog Implementation**
**Priority:** 🔴 CRITICAL  
**Duration:** Day 4 (8 hours)  
**Team:** Backend (4h) + Frontend (4h)  
**Branch:** `fix/product-catalog`

#### **Backend Implementation (4 hours)**
```typescript
// File: app/api/products/route.ts
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const featured = searchParams.get('featured')
    const search = searchParams.get('search')
    
    let query = supabase
      .from('products')
      .select(`
        *,
        categories(*),
        product_variants(*),
        product_images(*)
      `)
      .eq('is_active', true)
    
    if (category) {
      query = query.eq('category_id', category)
    }
    
    if (featured === 'true') {
      query = query.eq('is_featured', true)
    }
    
    if (search) {
      query = query.ilike('name', `%${search}%`)
    }
    
    const { data: products, error } = await query.order('created_at', { ascending: false })
    
    if (error) {
      console.error('Failed to fetch products:', error)
      return NextResponse.json({ error: 'Failed to fetch products' }, { status: 500 })
    }
    
    return NextResponse.json({ products })
  } catch (error: any) {
    console.error('Products API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// File: app/api/products/[id]/route.ts
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { data: product, error } = await supabase
      .from('products')
      .select(`
        *,
        categories(*),
        product_variants(*),
        product_images(*)
      `)
      .eq('id', params.id)
      .eq('is_active', true)
      .single()
    
    if (error || !product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 })
    }
    
    return NextResponse.json({ product })
  } catch (error: any) {
    console.error('Product detail API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
```

#### **Frontend Implementation (4 hours)**
```typescript
// File: app/products/page.tsx
'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import Link from 'next/link'
import Image from 'next/image'

interface Product {
  id: string
  name: string
  description: string
  price: number
  image: string
  is_featured: boolean
  categories: { name: string }
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  
  useEffect(() => {
    fetchProducts()
  }, [search, category])
  
  const fetchProducts = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (search) params.append('search', search)
      if (category) params.append('category', category)
      
      const response = await fetch(`/api/products?${params}`)
      const data = await response.json()
      
      if (data.products) {
        setProducts(data.products)
      }
    } catch (error) {
      console.error('Failed to fetch products:', error)
    } finally {
      setLoading(false)
    }
  }
  
  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <div className="h-48 bg-gray-200 rounded-t-lg"></div>
              <CardContent className="p-4">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded mb-4"></div>
                <div className="h-8 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }
  
  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Products</h1>
        <div className="flex gap-4 mb-6">
          <Input
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-sm"
          />
        </div>
      </div>
      
      {products.length === 0 ? (
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold mb-2">No products found</h2>
          <p className="text-gray-600">Try adjusting your search criteria</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="hover:shadow-lg transition-shadow">
              <div className="relative h-48">
                <Image
                  src={product.image || '/placeholder.jpg'}
                  alt={product.name}
                  fill
                  className="object-cover rounded-t-lg"
                />
                {product.is_featured && (
                  <Badge className="absolute top-2 right-2">Featured</Badge>
                )}
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">{product.name}</h3>
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                  {product.description}
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold">${product.price}</span>
                  <Link href={`/products/${product.id}`}>
                    <Button>View Details</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

// File: app/products/[id]/page.tsx
'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useCart } from '@/lib/cart-context'
import { toast } from 'sonner'
import Image from 'next/image'

export default function ProductDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { addItem } = useCart()
  const [product, setProduct] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [selectedVariant, setSelectedVariant] = useState<any>(null)
  
  useEffect(() => {
    if (params.id) {
      fetchProduct(params.id as string)
    }
  }, [params.id])
  
  const fetchProduct = async (id: string) => {
    try {
      setLoading(true)
      const response = await fetch(`/api/products/${id}`)
      const data = await response.json()
      
      if (data.product) {
        setProduct(data.product)
        if (data.product.product_variants?.length > 0) {
          setSelectedVariant(data.product.product_variants[0])
        }
      } else {
        toast.error('Product not found')
        router.push('/products')
      }
    } catch (error) {
      console.error('Failed to fetch product:', error)
      toast.error('Failed to load product')
    } finally {
      setLoading(false)
    }
  }
  
  const handleAddToCart = () => {
    if (!product) return
    
    const cartItem = {
      productId: product.id,
      variantId: selectedVariant?.id,
      name: product.name,
      price: selectedVariant?.price || product.price,
      image: product.image,
      quantity: 1,
      customizations: {
        product: {
          id: product.id,
          name: product.name,
          image: product.image
        },
        variant: selectedVariant
      }
    }
    
    addItem(cartItem)
    toast.success('Added to cart!')
  }
  
  const handleCustomize = () => {
    router.push(`/services/digital-printing?product=${product.id}`)
  }
  
  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="h-96 bg-gray-200 rounded-lg"></div>
            <div className="space-y-4">
              <div className="h-8 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-12 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }
  
  if (!product) {
    return (
      <div className="container mx-auto p-6 text-center">
        <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
        <Button onClick={() => router.push('/products')}>Back to Products</Button>
      </div>
    )
  }
  
  return (
    <div className="container mx-auto p-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="relative h-96">
          <Image
            src={product.image || '/placeholder.jpg'}
            alt={product.name}
            fill
            className="object-cover rounded-lg"
          />
        </div>
        
        <div className="space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h1 className="text-3xl font-bold">{product.name}</h1>
              {product.is_featured && <Badge>Featured</Badge>}
            </div>
            <p className="text-gray-600 mb-4">{product.description}</p>
            <p className="text-2xl font-bold">${selectedVariant?.price || product.price}</p>
          </div>
          
          {product.product_variants?.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Options:</h3>
              <div className="space-y-2">
                {product.product_variants.map((variant: any) => (
                  <Card 
                    key={variant.id} 
                    className={`cursor-pointer transition-colors ${
                      selectedVariant?.id === variant.id ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => setSelectedVariant(variant)}
                  >
                    <CardContent className="p-3">
                      <div className="flex justify-between items-center">
                        <span>{variant.name}</span>
                        <span className="font-semibold">${variant.price}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
          
          <div className="space-y-3">
            <Button onClick={handleCustomize} className="w-full" size="lg">
              Customize This Product
            </Button>
            <Button onClick={handleAddToCart} variant="outline" className="w-full" size="lg">
              Add to Cart
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
```

#### **Testing Checklist**
- [ ] Product listing page displays products
- [ ] Product search and filtering works
- [ ] Product detail pages load correctly
- [ ] Product images display properly
- [ ] Product variants are selectable
- [ ] Add to cart functionality works
- [ ] Customize button navigates correctly

---

### **🛒 TASK-005: Cart Functionality Fix**
**Priority:** 🔴 CRITICAL  
**Duration:** Day 5 (8 hours)  
**Team:** Frontend (8h)  
**Branch:** `fix/cart-functionality`

#### **Cart Context Implementation (4 hours)**
```typescript
// File: lib/cart-context.tsx
'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { toast } from 'sonner'

interface CartItem {
  productId: string
  variantId?: string
  designId?: string
  name: string
  price: number
  image: string
  quantity: number
  customizations?: any
}

interface CartContextType {
  items: CartItem[]
  addItem: (item: CartItem) => void
  removeItem: (productId: string, variantId?: string) => void
  updateQuantity: (productId: string, quantity: number, variantId?: string) => void
  clearCart: () => void
  total: number
  itemCount: number
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  
  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('cart')
    if (savedCart) {
      try {
        setItems(JSON.parse(savedCart))
      } catch (error) {
        console.error('Failed to parse saved cart:', error)
        localStorage.removeItem('cart')
      }
    }
  }, [])
  
  // Save cart to localStorage whenever items change
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(items))
  }, [items])
  
  const addItem = (newItem: CartItem) => {
    setItems(currentItems => {
      const existingItemIndex = currentItems.findIndex(
        item => item.productId === newItem.productId && 
               item.variantId === newItem.variantId &&
               item.designId === newItem.designId
      )
      
      if (existingItemIndex > -1) {
        // Update quantity of existing item
        const updatedItems = [...currentItems]
        updatedItems[existingItemIndex].quantity += newItem.quantity
        return updatedItems
      } else {
        // Add new item
        return [...currentItems, newItem]
      }
    })
    
    toast.success(`${newItem.name} added to cart`)
  }
  
  const removeItem = (productId: string, variantId?: string) => {
    setItems(currentItems => 
      currentItems.filter(item => 
        !(item.productId === productId && item.variantId === variantId)
      )
    )
    toast.success('Item removed from cart')
  }
  
  const updateQuantity = (productId: string, quantity: number, variantId?: string) => {
    if (quantity <= 0) {
      removeItem(productId, variantId)
      return
    }
    
    setItems(currentItems => 
      currentItems.map(item => 
        item.productId === productId && item.variantId === variantId
          ? { ...item, quantity }
          : item
      )
    )
  }
  
  const clearCart = () => {
    setItems([])
    localStorage.removeItem('cart')
    toast.success('Cart cleared')
  }
  
  const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0)
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0)
  
  return (
    <CartContext.Provider value={{
      items,
      addItem,
      removeItem,
      updateQuantity,
      clearCart,
      total,
      itemCount
    }}>
      {children}
    </CartContext.Provider>
  )
}

export const useCart = () => {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider')
  }
  return context
}
```

#### **Cart UI Components (4 hours)**
```typescript
// File: components/cart-sidebar.tsx
'use client'

import { useState } from 'react'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { ShoppingCart, Plus, Minus, Trash2 } from 'lucide-react'
import { useCart } from '@/lib/cart-context'
import { useRouter } from 'next/navigation'
import Image from 'next/image'

export function CartSidebar() {
  const { items, updateQuantity, removeItem, total, itemCount, clearCart } = useCart()
  const [open, setOpen] = useState(false)
  const router = useRouter()
  
  const handleCheckout = () => {
    setOpen(false)
    router.push('/checkout')
  }
  
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" className="relative">
          <ShoppingCart className="h-4 w-4" />
          {itemCount > 0 && (
            <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 text-xs">
              {itemCount}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle>Shopping Cart ({itemCount} items)</SheetTitle>
        </SheetHeader>
        
        <div className="flex flex-col h-full">
          <div className="flex-1 overflow-y-auto py-4">
            {items.length === 0 ? (
              <div className="text-center py-8">
                <ShoppingCart className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">Your cart is empty</p>
              </div>
            ) : (
              <div className="space-y-4">
                {items.map((item) => (
                  <div key={`${item.productId}-${item.variantId}`} className="flex gap-3 p-3 border rounded-lg">
                    <div className="relative w-16 h-16 flex-shrink-0">
                      <Image
                        src={item.image || '/placeholder.jpg'}
                        alt={item.name}
                        fill
                        className="object-cover rounded"
                      />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm truncate">{item.name}</h4>
                      <p className="text-sm text-gray-600">${item.price}</p>
                      
                      <div className="flex items-center gap-2 mt-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateQuantity(item.productId, item.quantity - 1, item.variantId)}
                          className="h-6 w-6 p-0"
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        
                        <span className="text-sm font-medium w-8 text-center">
                          {item.quantity}
                        </span>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateQuantity(item.productId, item.quantity + 1, item.variantId)}
                          className="h-6 w-6 p-0"
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => removeItem(item.productId, item.variantId)}
                          className="h-6 w-6 p-0 ml-auto text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {items.length > 0 && (
            <div className="border-t pt-4 space-y-4">
              <div className="flex justify-between items-center">
                <span className="font-semibold">Total:</span>
                <span className="font-bold text-lg">${total.toFixed(2)}</span>
              </div>
              
              <div className="space-y-2">
                <Button onClick={handleCheckout} className="w-full" size="lg">
                  Checkout
                </Button>
                <Button onClick={clearCart} variant="outline" className="w-full">
                  Clear Cart
                </Button>
              </div>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  )
}

// File: app/cart/page.tsx
'use client'

import { useCart } from '@/lib/cart-context'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Plus, Minus, Trash2, ShoppingCart } from 'lucide-react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'

export default function CartPage() {
  const { items, updateQuantity, removeItem, total, itemCount, clearCart } = useCart()
  const router = useRouter()
  
  if (items.length === 0) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center py-12">
          <ShoppingCart className="h-24 w-24 mx-auto text-gray-400 mb-6" />
          <h1 className="text-2xl font-bold mb-4">Your cart is empty</h1>
          <p className="text-gray-600 mb-6">Add some products to get started</p>
          <Link href="/products">
            <Button size="lg">Browse Products</Button>
          </Link>
        </div>
      </div>
    )
  }
  
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart ({itemCount} items)</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Cart Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {items.map((item, index) => (
                  <div key={`${item.productId}-${item.variantId}`}>
                    {index > 0 && <Separator className="my-4" />}
                    
                    <div className="flex gap-4">
                      <div className="relative w-20 h-20 flex-shrink-0">
                        <Image
                          src={item.image || '/placeholder.jpg'}
                          alt={item.name}
                          fill
                          className="object-cover rounded"
                        />
                      </div>
                      
                      <div className="flex-1">
                        <h3 className="font-semibold">{item.name}</h3>
                        <p className="text-gray-600">${item.price} each</p>
                        
                        <div className="flex items-center gap-3 mt-3">
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateQuantity(item.productId, item.quantity - 1, item.variantId)}
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            
                            <span className="font-medium w-12 text-center">
                              {item.quantity}
                            </span>
                            
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateQuantity(item.productId, item.quantity + 1, item.variantId)}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => removeItem(item.productId, item.variantId)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Remove
                          </Button>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <p className="font-bold text-lg">
                          ${(item.price * item.quantity).toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span>Subtotal ({itemCount} items):</span>
                <span>${total.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between">
                <span>Shipping:</span>
                <span>Calculated at checkout</span>
              </div>
              
              <Separator />
              
              <div className="flex justify-between font-bold text-lg">
                <span>Total:</span>
                <span>${total.toFixed(2)}</span>
              </div>
              
              <div className="space-y-3">
                <Button 
                  onClick={() => router.push('/checkout')} 
                  className="w-full" 
                  size="lg"
                >
                  Proceed to Checkout
                </Button>
                
                <Button 
                  onClick={clearCart} 
                  variant="outline" 
                  className="w-full"
                >
                  Clear Cart
                </Button>
              </div>
              
              <div className="text-center">
                <Link href="/products" className="text-blue-600 hover:underline">
                  Continue Shopping
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
```

#### **Testing Checklist**
- [ ] Add to cart functionality works from product pages
- [ ] Cart state persists across page refreshes
- [ ] Cart items can be updated (quantity changes)
- [ ] Cart items can be removed
- [ ] Cart totals calculate correctly
- [ ] Cart sidebar displays properly
- [ ] Cart page shows all items
- [ ] Clear cart functionality works
- [ ] Checkout navigation works

---

## 📊 SPRINT 1 COMPLETION CRITERIA

### **Definition of Done**
Each task must meet ALL criteria before being marked complete:

#### **TASK-001: Authentication System**
- [ ] Test users can register successfully
- [ ] Test users can login with valid credentials
- [ ] Authentication state persists across browser sessions
- [ ] Password reset emails are sent and functional
- [ ] Role-based access control works (admin vs customer)
- [ ] All authentication forms have proper validation
- [ ] Error messages are user-friendly and helpful

#### **TASK-002: Database Schema**
- [ ] All migrations execute without errors
- [ ] Foreign key constraints are properly implemented
- [ ] RLS policies prevent unauthorized access
- [ ] Seed data is successfully inserted
- [ ] Database backup procedures are documented
- [ ] All tables have proper indexes for performance

#### **TASK-003: Order Creation**
- [ ] Orders are created and persisted to database
- [ ] Order items are created with proper image URLs
- [ ] Payment confirmation updates order status correctly
- [ ] Order confirmation emails are sent
- [ ] Orders appear in user dashboard
- [ ] Admin can view and manage orders
- [ ] Order numbers are unique and properly formatted

#### **TASK-004: Product Catalog**
- [ ] Product listing page displays all active products
- [ ] Product search functionality works
- [ ] Product detail pages load with all information
- [ ] Product images display with proper fallbacks
- [ ] Product variants are selectable
- [ ] Add to cart works from product pages
- [ ] Customize button navigates to design editor

#### **TASK-005: Cart Functionality**
- [ ] Add to cart works from all product pages
- [ ] Cart state persists across browser sessions
- [ ] Cart quantities can be updated
- [ ] Cart items can be removed
- [ ] Cart totals calculate correctly
- [ ] Cart sidebar and page both work
- [ ] Checkout navigation is functional

### **Sprint 1 Success Metrics**
- [ ] 100% of authentication tests passing
- [ ] Users can complete full registration → login → browse → add to cart → checkout flow
- [ ] Database contains proper seed data for testing
- [ ] All critical API endpoints return proper responses
- [ ] No console errors during normal user workflows
- [ ] Page load times under 3 seconds
- [ ] Mobile responsiveness maintained

---

## 🚀 NEXT PHASES OVERVIEW

### **Phase 2: Core Business Logic (Week 2)**
- Payment gateway integration testing
- AI Studio authentication and functionality
- Order items image system implementation
- Admin dashboard core functions

### **Phase 3: Enhanced Features (Week 3-4)**
- Email service integration
- Quote management system
- Digital printing services enhancement

### **Phase 4: Production Ready (Week 5-6)**
- Performance optimization
- Advanced testing and QA
- Security audit
- Production deployment preparation

---

## 📋 DAILY STANDUP TEMPLATE

### **Daily Questions for Each Team Member:**
1. **Yesterday:** What tasks did you complete?
2. **Today:** What tasks are you working on?
3. **Blockers:** What's preventing you from making progress?
4. **Help Needed:** Do you need assistance from other team members?

### **Sprint Progress Tracking:**
- **Tasks Completed:** X/5
- **Tasks In Progress:** X/5
- **Tasks Blocked:** X/5
- **Sprint Health:** 🟢 On Track / 🟡 At Risk / 🔴 Behind Schedule

---

## 🎯 CONCLUSION

This action plan provides a systematic approach to fixing all critical issues identified in the acceptance testing report. By following this plan:

1. **Week 1** will establish a functional foundation
2. **Week 2** will enable complete user workflows
3. **Week 3-4** will add business value features
4. **Week 5-6** will prepare for production deployment

**Success depends on:**
- Following the plan systematically
- Completing each task's acceptance criteria
- Daily team coordination and communication
- Proper testing at each stage
- Maintaining code quality throughout

**The platform will transform from 65% functional to production-ready in 6 weeks with this focused approach! 🚀**