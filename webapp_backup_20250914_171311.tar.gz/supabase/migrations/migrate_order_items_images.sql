-- Migration to populate image URLs for existing order items
-- This migration extracts image data from customizations JSON and related tables
-- to populate the new image URL columns for orders created before the image system

-- Step 1: Update design_image_url from customizations JSON
UPDATE order_items 
SET design_image_url = CASE
  -- Try to get from customizations.aiDesign.previewUrl
  WHEN customizations->'aiDesign'->>'previewUrl' IS NOT NULL 
    THEN customizations->'aiDesign'->>'previewUrl'
  -- Try to get from customizations.customDesign.customizedProductImage
  WHEN customizations->'customDesign'->>'customizedProductImage' IS NOT NULL 
    THEN customizations->'customDesign'->>'customizedProductImage'
  -- Try to get from customizations.preview_url
  WHEN customizations->>'preview_url' IS NOT NULL 
    THEN customizations->>'preview_url'
  -- Try to get from customizations.customizedProductImage
  WHEN customizations->>'customizedProductImage' IS NOT NULL 
    THEN customizations->>'customizedProductImage'
  -- Try to get from customizations.designUrl
  WHEN customizations->>'designUrl' IS NOT NULL 
    THEN customizations->>'designUrl'
  -- Try to get from customizations.storageUrl
  WHEN customizations->>'storageUrl' IS NOT NULL 
    THEN customizations->>'storageUrl'
  ELSE design_image_url
END
WHERE design_image_url IS NULL 
  AND customizations IS NOT NULL;

-- Step 2: Update product_image_url from customizations.product.image
UPDATE order_items 
SET product_image_url = customizations->'product'->>'image'
WHERE product_image_url IS NULL 
  AND customizations->'product'->>'image' IS NOT NULL;

-- Step 3: Update customized_image_url from customizations
UPDATE order_items 
SET customized_image_url = CASE
  -- Try to get from customizations.customDesign.customizedProductImage
  WHEN customizations->'customDesign'->>'customizedProductImage' IS NOT NULL 
    THEN customizations->'customDesign'->>'customizedProductImage'
  -- Try to get from customizations.aiDesign.previewUrl
  WHEN customizations->'aiDesign'->>'previewUrl' IS NOT NULL 
    THEN customizations->'aiDesign'->>'previewUrl'
  -- Try to get from customizations.customizedProductImage
  WHEN customizations->>'customizedProductImage' IS NOT NULL 
    THEN customizations->>'customizedProductImage'
  ELSE customized_image_url
END
WHERE customized_image_url IS NULL 
  AND customizations IS NOT NULL;

-- Step 4: Update design_file_url and print_ready_file_url from customizations
UPDATE order_items 
SET design_file_url = CASE
  -- Try to get from customizations.customDesign.customizedProductImage
  WHEN customizations->'customDesign'->>'customizedProductImage' IS NOT NULL 
    THEN customizations->'customDesign'->>'customizedProductImage'
  -- Try to get from customizations.aiDesign.previewUrl
  WHEN customizations->'aiDesign'->>'previewUrl' IS NOT NULL 
    THEN customizations->'aiDesign'->>'previewUrl'
  -- Try to get from design_image_url if available
  WHEN design_image_url IS NOT NULL 
    THEN design_image_url
  ELSE design_file_url
END
WHERE design_file_url IS NULL;

UPDATE order_items 
SET print_ready_file_url = COALESCE(design_file_url, design_image_url)
WHERE print_ready_file_url IS NULL;

-- Step 5: Try to populate missing images from digital_products table if design_id exists
UPDATE order_items 
SET design_image_url = dp.preview_url
FROM digital_products dp
WHERE order_items.design_id = dp.id::text
  AND order_items.design_image_url IS NULL
  AND dp.preview_url IS NOT NULL;

UPDATE order_items 
SET design_file_url = dp.download_url
FROM digital_products dp
WHERE order_items.design_id = dp.id::text
  AND order_items.design_file_url IS NULL
  AND dp.download_url IS NOT NULL;

-- Step 6: Try to populate missing images from designs table if design_id exists
UPDATE order_items 
SET design_image_url = d.thumbnail_url
FROM designs d
WHERE order_items.design_id = d.id::text
  AND order_items.design_image_url IS NULL
  AND d.thumbnail_url IS NOT NULL;

-- Step 7: Set fallback placeholder images for items that still don't have images
UPDATE order_items 
SET design_image_url = '/placeholder.svg?height=200&width=200&text=Design'
WHERE design_image_url IS NULL 
  AND design_id IS NOT NULL;

UPDATE order_items 
SET product_image_url = '/placeholder.svg?height=200&width=200&text=Product'
WHERE product_image_url IS NULL;

-- Step 8: Create a summary report of the migration
DO $$
DECLARE
    total_items INTEGER;
    items_with_design_images INTEGER;
    items_with_product_images INTEGER;
    items_with_customized_images INTEGER;
    items_with_design_files INTEGER;
BEGIN
    SELECT COUNT(*) INTO total_items FROM order_items;
    SELECT COUNT(*) INTO items_with_design_images FROM order_items WHERE design_image_url IS NOT NULL;
    SELECT COUNT(*) INTO items_with_product_images FROM order_items WHERE product_image_url IS NOT NULL;
    SELECT COUNT(*) INTO items_with_customized_images FROM order_items WHERE customized_image_url IS NOT NULL;
    SELECT COUNT(*) INTO items_with_design_files FROM order_items WHERE design_file_url IS NOT NULL;
    
    RAISE NOTICE 'Order Items Image Migration Summary:';
    RAISE NOTICE 'Total order items: %', total_items;
    RAISE NOTICE 'Items with design images: % (%.1f%%)', items_with_design_images, (items_with_design_images::float / total_items * 100);
    RAISE NOTICE 'Items with product images: % (%.1f%%)', items_with_product_images, (items_with_product_images::float / total_items * 100);
    RAISE NOTICE 'Items with customized images: % (%.1f%%)', items_with_customized_images, (items_with_customized_images::float / total_items * 100);
    RAISE NOTICE 'Items with design files: % (%.1f%%)', items_with_design_files, (items_with_design_files::float / total_items * 100);
END $$;

-- Step 9: Create an index on image columns for better performance
CREATE INDEX IF NOT EXISTS idx_order_items_design_image_url ON order_items(design_image_url) WHERE design_image_url IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_order_items_product_image_url ON order_items(product_image_url) WHERE product_image_url IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_order_items_customized_image_url ON order_items(customized_image_url) WHERE customized_image_url IS NOT NULL;

-- Step 10: Update the order_items_with_images view if it exists
DROP VIEW IF EXISTS order_items_with_images;
CREATE VIEW order_items_with_images AS
SELECT 
    oi.*,
    CASE 
        WHEN oi.customized_image_url IS NOT NULL THEN 'customized'
        WHEN oi.design_image_url IS NOT NULL THEN 'design'
        WHEN oi.product_image_url IS NOT NULL THEN 'product'
        ELSE 'none'
    END as primary_image_type,
    COALESCE(
        oi.customized_image_url,
        oi.design_image_url,
        oi.product_image_url,
        '/placeholder.svg?height=200&width=200&text=No+Image'
    ) as display_image_url
FROM order_items oi;

-- Grant permissions
GRANT SELECT ON order_items_with_images TO authenticated;
GRANT SELECT ON order_items_with_images TO anon;

COMMIT;